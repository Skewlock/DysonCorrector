void afficherChiffre(int num);

int main(void)
{
    afficherChiffre(42);
}