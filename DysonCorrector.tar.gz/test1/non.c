#include <stdio.h>

void afficherChiffre(int num)
{
    printf("%d\n", num);
}