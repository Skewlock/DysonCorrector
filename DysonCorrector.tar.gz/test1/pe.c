#include <stdio.h>

void afficherChiffre(int num)
{
    (void)num;
    printf("Hello World !\n");
}